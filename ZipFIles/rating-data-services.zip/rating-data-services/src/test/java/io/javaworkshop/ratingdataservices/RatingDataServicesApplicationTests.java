package io.javaworkshop.ratingdataservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RatingDataServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
